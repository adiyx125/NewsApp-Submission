package com.example.newsapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class NewsDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_detail)

        // 1. Get the link out of the envelope
        val articleUrl = intent.getStringExtra("ARTICLE_URL")

        // 2. Find our mini web browser and load the link!
        val webView = findViewById<android.webkit.WebView>(R.id.webView)
        webView.webViewClient = android.webkit.WebViewClient() // This keeps the website inside your app
        webView.settings.javaScriptEnabled = true
        if (articleUrl != null) {
            webView.loadUrl(articleUrl)
        }
    }
}