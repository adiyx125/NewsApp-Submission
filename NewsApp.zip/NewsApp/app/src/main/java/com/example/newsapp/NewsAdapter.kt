package com.example.newsapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
// Android Studio might ask you to import your specific 'databinding.ItemNewsBinding' here.

class NewsAdapter(
    private var articles: List<Article>,
    private val onItemClick: (Article) -> Unit
) : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    // This connects to the item_news.xml file we just made!
    inner class NewsViewHolder(val binding: com.example.newsapp.databinding.ItemNewsBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val binding = com.example.newsapp.databinding.ItemNewsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return NewsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val article = articles[position]

        holder.binding.newsTitle.text = article.title
        holder.binding.newsDescription.text = article.description ?: ""

        // THE MAGIC TRICK:
        if (article.urlToImage == null) {
            // If there is no picture, hide the Image box completely!
            holder.binding.newsImage.visibility = android.view.View.GONE
        } else {
            // If there IS a picture, make sure the box is visible and load it!
            holder.binding.newsImage.visibility = android.view.View.VISIBLE

            Glide.with(holder.itemView.context)
                .load(article.urlToImage)
                .into(holder.binding.newsImage)
        }

        holder.itemView.setOnClickListener {
            onItemClick(article)
        }
    }

    override fun getItemCount(): Int {
        return articles.size
    }

    // This updates the list when the internet finishes downloading the news
    fun updateData(newArticles: List<Article>) {
        articles = newArticles
        notifyDataSetChanged()
    }
}