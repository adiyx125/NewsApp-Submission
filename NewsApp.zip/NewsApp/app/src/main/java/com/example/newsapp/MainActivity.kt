package com.example.newsapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.newsapp.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: NewsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Setup Data Binding for the screen
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 2. Setup the RecyclerView list
        setupRecyclerView()

        // 3. Download the news!
        fetchNews()
    }

    private fun setupRecyclerView() {
        // We start with an empty list. When a user clicks an item, we show a Toast message for now.
        adapter = NewsAdapter(emptyList()) { clickedArticle ->
            val intent = Intent(this@MainActivity, NewsDetailActivity::class.java)
            intent.putExtra("ARTICLE_URL", clickedArticle.url)
            startActivity(intent)
            // We will add the code to go to the Details Screen here next!
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun fetchNews() {
        // ⚠️ PASTE YOUR NEWSAPI.ORG KEY HERE ⚠️
        val myApiKey = "3e6ea04350e04d6c8bf90a9a99b96909"

        RetrofitInstance.api.getTopHeadlines(country = "us", apiKey = myApiKey).enqueue(object : Callback<NewsResponse> {
            override fun onResponse(call: Call<NewsResponse>, response: Response<NewsResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val articlesList = response.body()!!.articles

                    // ADD THIS LINE HERE:


                    adapter.updateData(articlesList) // Give the news to the adapter!
                } else {
                    Toast.makeText(this@MainActivity, "Error: ${response.code()}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<NewsResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Internet Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}